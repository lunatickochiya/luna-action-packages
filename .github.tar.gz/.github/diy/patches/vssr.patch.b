--- a/luci-app-vssr/root/usr/share/vssr/subscribe.lua
+++ b/luci-app-vssr/root/usr/share/vssr/subscribe.lua
@@ -369,7 +369,7 @@ end
 local function wget(url)
     local stdout =
         luci.sys.exec(
-        'wget-ssl -q --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36" --no-check-certificate -t 3 -T 10 -O- "' .. url .. '"'
+        'wget -q --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36" --no-check-certificate -t 3 -T 10 -O- "' .. url .. '"'
     )
     return trim(stdout)
 end

--- a/luci-app-vssr/luasrc/view/vssr/tblsection.htm
+++ b/luci-app-vssr/luasrc/view/vssr/tblsection.htm
@@ -7,7 +7,7 @@
         <button class="cbi-button  cbi-button-check ">
             <%:Ping All Servers%>
         </button><span class="panel-title">总计
-            <%- print(self.des)-%>个节点
+            <%=self.des%>个节点
         </span>
         <div style="clear:both;"></div>
     </div>
